<?php declare(strict_types=1);

namespace pcrov\JsonReader;

class Exception extends \Exception
{

}
