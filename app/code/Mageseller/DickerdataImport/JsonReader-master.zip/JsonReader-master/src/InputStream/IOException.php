<?php declare(strict_types=1);

namespace pcrov\JsonReader\InputStream;

use pcrov\JsonReader\Exception;

class IOException extends Exception
{

}
