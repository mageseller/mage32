<?php declare(strict_types=1);

namespace pcrov\JsonReader\Parser;

use pcrov\JsonReader\Exception;

class ParseException extends Exception
{

}
