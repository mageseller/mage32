<?php declare(strict_types=1);

namespace pcrov\JsonReader;

class InvalidArgumentException extends Exception
{

}
